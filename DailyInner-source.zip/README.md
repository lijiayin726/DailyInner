# DailyInner

DailyInner 是一个记录情绪、身体状态和经期线索的本地优先 Web 应用，并提供 Android 包壳版本。

## 内容

- `app/`：Web 应用源代码
- `static/`、`public/`：网页资源与图标
- `android/`：Android Studio / Capacitor 工程
- `apk/dailyinner-debug.apk`：可直接安装测试的 Android APK
- `scripts/`：构建和图标辅助脚本

## 本地运行

```bash
npm install
npm run dev
```

## 构建 Web

```bash
npm run build
```

## 构建 Android

先完成 Web 构建并同步 Capacitor 资源，再使用 Android Studio 打开 `android/` 目录进行构建。

## 数据说明

当前版本不需要登录或云端数据库，记录默认保存在使用者自己的设备本地。卸载 App 时，本地数据会被清空。请不要把 API 密钥、签名文件或个人数据提交到仓库。
